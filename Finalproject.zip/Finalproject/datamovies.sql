SELECT * FROM datamovies.bookings;
